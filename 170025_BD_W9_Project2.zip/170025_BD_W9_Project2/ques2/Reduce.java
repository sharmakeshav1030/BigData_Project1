package ques2;

import java.util.Iterator;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import org.apache.hadoop.io.Text;


/*******
 * <p>
 * Title: Reduce
 * </p>
 *
 * <p>
 * Description: This class find outs which day was hot and cold.
 * </p>
 *
 * @author Keshav Sharma
 *
 * @version 1.00 2019-09-05
 *
 */

public class Reduce extends Reducer<Text, Text, Text, Text> {

	public void reduce(Text Key, Iterator<Text> Values, Context context)
			throws IOException, InterruptedException {

		String temperature = Values.next().toString();
		context.write(Key, new Text(temperature));
	}

}