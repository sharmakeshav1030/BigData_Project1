package ques2;

import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/*******
 * <p>
 * Title: Map
 * </p>
 *
 * <p>
 * Description: This class find outs which day was hot and cold.
 * </p>
 *
 * @author Keshav Sharma
 *
 * @version 1.00 2019-09-05
 *
 */

public class Map extends Mapper<LongWritable, Text, Text, Text> {
	public static final int MISSING = 9999;

	public void map(LongWritable arg0, Text Value, Context context)
			throws IOException, InterruptedException {

		String line = Value.toString();


		if (!(line.length() == 0)) {

			// date
			String date = line.substring(6, 14);
			// maximum temperature
			float temp_Max = Float.parseFloat(line.substring(39, 45).trim());
			// minimum temperature
			float temp_Min = Float.parseFloat(line.substring(47, 53).trim());

			// Printing hot or cold.
			if (temp_Max != MISSING && temp_Min != MISSING) {
				context.write(
						new Text("|Time/Date: " + date + " | "),
						new Text(String.valueOf(" Maximum Temperature: "
								+ temp_Max + "\t|  Minimum Temperature: "
								+ temp_Min + "\t|")));
			}

		}
	}
}
