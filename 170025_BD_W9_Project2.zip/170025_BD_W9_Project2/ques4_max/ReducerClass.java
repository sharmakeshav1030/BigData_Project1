package ques4_max;

import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/*******
 * <p>
 * Title: ReducerClass
 * </p>
 *
 * <p>
 * Description: This class find outs the maximum temperature of the day.
 * </p>
 *
 * @author Keshav Sharma
 *
 * @version 1.00 2019-09-05
 *
 */

public class ReducerClass extends
		Reducer<Text, FloatWritable, FloatWritable, Text> {

	private TreeMap<Float, String> tmap;

	@Override
	public void setup(Context context) throws IOException, InterruptedException {
		tmap = new TreeMap<Float, String>();
	}

	@Override
	public void reduce(Text key, Iterable<FloatWritable> values, Context context)
			throws IOException, InterruptedException {

		String name = key.toString();
		float count = 0;

		for (FloatWritable val : values) {
			count = val.get();
		}

		tmap.put(count, name);

		if (tmap.size() > 10) {
			tmap.remove(tmap.firstKey());
		}
	}

	@Override
	public void cleanup(Context context) throws IOException,
			InterruptedException {

		for (Map.Entry<Float, String> entry : tmap.entrySet()) {

			float count = entry.getKey();
			String name = entry.getValue();
			context.write(new FloatWritable(count), new Text(name));
		}
	}
}
